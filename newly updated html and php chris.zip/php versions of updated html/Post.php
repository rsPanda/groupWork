<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Post</title>
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.js" integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE=" crossorigin="anonymous"></script>
<!-- <?php -->


<!-- ?> -->
<link rel="stylesheet" href=" jquery.mobile.min.css" />
<script src="redirect.js"></script>
</head>
<body>
<div data-role="page">
<div data-role="header" role="banner">
<h1>Post</h1>
</div>
<table>
<tr>	<th>title</th>	<th>console</th>	<th>genre</th>	</tr>
<tr>	<td>title</td>	<td>console</td>	<td>genre</td>	</tr>
</table>
<div data-role="main" id="content">
<!-- this should be loading the post data into the text area -->
<textarea rows="27" cols="135">

</textarea>
<br/>
<br/>
</div>
<div data-role="footer">
<button id="btnFeeds" >Feeds</button>
<button id="btnFeedback" >FeedBack</button>
<button id="btnLogin" >Log In</button>
<p>&copy; GamesHub</p>
<p>&copy; Christopher Sanderson</p>
</div>
</div>
</body>
</html>