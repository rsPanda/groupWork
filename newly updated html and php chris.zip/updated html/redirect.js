$(document).ready(function(){
	$("#btnLogin").click(function (event){
		window.location.href = "login.html";
	});
	$("#btnFeedback").click(function (event){
		window.location.href = "Feedback.html";
	});
	$("#btnFeeds").click(function (event){
		window.location.href = "homepage.html";
	});
	$("#btnLogout").click(function (event){
		window.location.href = "logout.html";
	});
	$("#btnAddPost").click(function (event){
		window.location.href = "Add Post.html";
	});
	$("#btnPost").click(function (event){
		window.location.href = "post.html";
	});
	$("#create").click(function (event){
		window.location.href = "newuser.html";
	});
	$("#log").click(function (event){
		window.location.href = "login.html";
	});
	$("#post").click(function (event){
		window.location.href = "post.html";
	});
});